<div class="row">
            <div class="col-12">
              <footer class="c-footer">
                <p>© <?php echo date("Y"); ?> <?php echo $pdo_auth['name']; ?>, <?php echo $pdo_auth['tx_address']; ?></p>
                <span class="c-footer__divider">|</span>
                <nav>
                  <a class="c-footer__link" href="#">Terms</a>
                  <a class="c-footer__link" href="#">Privacy</a>
                  <a class="c-footer__link" href="#">FAQ</a>
                  <a class="c-footer__link" href="#">Help</a>
                </nav>
              </footer>
            </div>
          </div>