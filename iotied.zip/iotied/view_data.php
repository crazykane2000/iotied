<?php session_start();
    include 'administrator/connection.php';
    include 'administrator/function.php';
    $pdo_auth = authenticate();
    $pdo = new PDO($dsn, $user, $pass, $opt);  
    error_reporting( E_WARNING | E_PARSE);
?>
<?php $dag =  get_data_items_andd("request_access", "vendor_tx", $pdo_auth['tx_address'], "patient_tx", $_REQUEST['address']); 
   //print_r($dag);
  // echo $dag['type'];

  if ($dag['type']=="None"  || $dag['type']=="No Access" ) {
    header('Location:dashboard.php?choice=error&value=Access Is Not Given, No Access Rights are Given');
    exit();
  }
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Dashboard  | Iotied</title>
    <meta name="description" content="Iotied">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
    <link rel="apple-touch-icon" href="apple-touch-icon.png">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="css/neat.minc619.css?v=1.0">
    <style type="text/css">
      td{
        padding: 6px;
        padding-left: 20px;
        border-bottom: solid 1px #eee;
        text-transform: capitalize;
      }
    </style>
  </head>
  <body>

    <div class="o-page">
      <?php include 'sidebar.php'; ?>

      <main class="o-page__content">
        <?php include 'header.php'; ?>

        <div class="container-fluid">
          <?php include 'dashboard_stats.php'; ?>



          <?php $curl = curl_init();

              $patient = $_REQUEST['address'];
              $vendor = $pdo_auth['tx_address'];

              //echo $patient." / ".$vendor;

              
              curl_setopt_array($curl, array(
                CURLOPT_URL => "http://13.233.7.230:3005/api/dataManager/getDetails/patient",
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_POSTFIELDS =>"{\n  \"_vendorAddress\": \"$vendor\",\n  \"_patientAddress\": \"$patient\"\n}",
                  CURLOPT_HTTPHEADER => array(
                    "Content-Type: application/json"
                  ),
                ));

              $response = curl_exec($curl);

              curl_close($curl);

              if ($err) {
                echo "cURL Error #:" . $err;
              } else {
                $response = json_decode($response,true);
              } 
              //print_r($response);
              ?>
          <div class="row">
            <div class="col-12">
              <div class="c-table-responsive@wide" style="background-color: #fff;padding: 30px;border-radius: 4px;">
                <table class="c-table">
                  
                  <?php $value = $response;
                            
                            echo '<tr>
                                <td>Tx Address</td>
                                <td>'.$pdo_auth['tx_address'].'</td>
                              </tr>';

                              echo '<tr>
                                <td>patientAddress</td>
                                <td>'.$_REQUEST['address'].'</td>
                              </tr>';

                              

                              echo '<tr>
                                <td>First Name</td>
                                <td style="color:green;font-weight:bold">'.$value['First Name'].'</td>
                              </tr>';

                              echo '<tr>
                                <td>City</td>
                                <td>'.$value['City'].'</td>
                              </tr>';

                              echo '<tr>
                                <td>Home Phone</td>
                                <td>'.$value['Home Phone'].'</td>
                              </tr>';

                              echo '<tr>
                                <td>Emergency Contact</td>
                                <td>'.$value['Emergency Contact'].'</td>
                              </tr>';

                               echo '<tr>
                                <td>Diseases</td>
                                <td>'.$value['diseases'].'</td>
                              </tr>';

                              echo '<tr>
                                <td>ICD Codes</td>
                                <td>'.$value['icd_code'].'</td>
                              </tr>';

                              $vital_arr = $value['clinicalRemainderData']['VitalArr'];

                              ?>

                              <tr>
                                <td>
                                  <a href="sample_data.php?address=<?php echo $_REQUEST['address']; ?>" class="c-btn c-btn--success">Export Data Here</a>
                                </td>

                                <td>
                                  <a href="archieve_data.php?address=<?php echo $_REQUEST['address']; ?>" class="c-btn c-btn--info">Data Archive</a>
                                </td>
                              </tr>
                            </table>
                            <div style="padding: 20px"></div>

                              <nav class="c-tabs"> 
                                <div class="c-tabs__list nav nav-tabs" id="myTab" role="tablist">
                                  <a class="c-tabs__link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Personal Information</a>
                                  <a class="c-tabs__link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Wearable</a>
                                  <a class="c-tabs__link" id="nav-contact-tab" data-toggle="tab" href="#nav-contact" role="tab" aria-controls="nav-contact" aria-selected="false">Documents</a>
                                   <a class="c-tabs__link" id="nav-vital-tab" data-toggle="tab" href="#nav-vital" role="tab" aria-controls="nav-vital" aria-selected="false">Vitals</a>
                                </div>
                                <div class="c-tabs__content tab-content" id="nav-tabContent">
                                  <div class="c-tabs__pane active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                                    <h4>Personal Information</h4>
                                    <table class="c-table">
                                      <?php 
                                        if ($dag['type']=="Full Access" || $dag['type']=="PersonalInformation") {
                                          //print_r($value['clinicalRemainderData']['PersonalInformation']);
                                            foreach ($value['clinicalRemainderData']['PersonalInformation'] as $key1 => $value1) {
                                              foreach ($value1 as $key1 => $value1) {
                                                //print_r($value);
                                                echo '<tr>
                                                        <td>'.$key1.'</td>
                                                        <td>'.$value1.'</td>
                                                      </tr>';
                                              }
                                            }
                                        }


                                        $datau = strpos($dag['type'],"PersonalInformation" );
                                        if (is_numeric($datau)) {
                                          foreach ($value['clinicalRemainderData']['PersonalInformation'] as $key1 => $value1) {
                                              foreach ($value1 as $key1 => $value1) {
                                                //print_r($value);
                                                echo '<tr>
                                                        <td>'.$key1.'</td>
                                                        <td>'.$value1.'</td>
                                                      </tr>';
                                              }
                                            }
                                        } 
                                        
                                          
                                       ?>
                                    </table>

                                  </div>
                                  <div class="c-tabs__pane" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
                                    <h4>Wearable Data</h4><br/><br/>
                                    <table class="c-table">
                                      <?php 
                                        if ($dag['type']=="Full Access" || $dag['type']=="Wearable") {
                                          foreach ($value['clinicalRemainderData']['Wearable'] as $key2 => $value2) {
                                            foreach ($value2 as $key2 => $value2) {
                                              //print_r($value);
                                              if (is_array($value2)) {
                                                foreach ($value2 as $key2a => $value2a) {
                                                  //print_r($value2a);
                                                  foreach ($value2a as $key2b => $value2b) {
                                                    echo '<tr>
                                                      <td>'.$key2b.'</td>
                                                      <td>'.$value2b.'</td>
                                                    </tr>';
                                                  }
                                                  echo '<tr><td colspan=2 style="background-color:#cae5ff"></td></tr>';
                                                }
                                              }else{
                                                echo '<tr>
                                                      <td>'.$key2.'</td>
                                                      <td>'.$value2.'</td>
                                                    </tr>';
                                              }
                                              
                                            }
                                          }
                                        }

                                        $datau = strpos($dag['type'],"Wearable" );
                                        if (is_numeric($datau)) {
                                         foreach ($value['clinicalRemainderData']['Wearable'] as $key2 => $value2) {
                                            foreach ($value2 as $key2 => $value2) {
                                              //print_r($value);
                                              if (is_array($value2)) {
                                                foreach ($value2 as $key2a => $value2a) {
                                                  //print_r($value2a);
                                                  foreach ($value2a as $key2b => $value2b) {
                                                    echo '<tr>
                                                      <td>'.$key2b.'</td>
                                                      <td>'.$value2b.'</td>
                                                    </tr>';
                                                  }
                                                  echo '<tr><td colspan=2 style="background-color:#cae5ff"></td></tr>';
                                                }
                                              }else{
                                                echo '<tr>
                                                      <td>'.$key2.'</td>
                                                      <td>'.$value2.'</td>
                                                    </tr>';
                                              }
                                              
                                            }
                                          }
                                        } 

                                       ?>
                                    </table>
                                  </div>
                                  <div class="c-tabs__pane" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab">
                                    <h4>Documents </h4>
                                    <table class="c-table">
                                      <?php 
                                      if ($dag['type']=="Full Access" || $dag['type']=="Document") {
                                      foreach ($value['clinicalRemainderData']['Document'] as $key3 => $value3) {
                                        foreach ($value3 as $key3 => $value3) {
                                          //print_r($value);
                                          if (is_array($value3)) {
                                            foreach ($value3 as $key3a => $value3a) {
                                              //print_r($value3a);
                                              foreach ($value3a as $key3b => $value3b) {
                                                echo '<tr>
                                                  <td>'.$key3b.'</td>
                                                  <td>'.$value3b.'</td>
                                                </tr>';
                                              }
                                              echo '<tr><td colspan=2 style="background-color:#cae5ff"></td></tr>';
                                            }
                                          }else{
                                            echo '<tr>
                                                  <td>'.$key3.'</td>
                                                  <td>'.$value3.'</td>
                                                </tr>';
                                          }
                                          
                                        }
                                      } 

                                    }

                                    $datau = strpos($dag['type'],"Document" );
                                        if (is_numeric($datau)) {
                                         foreach ($value['clinicalRemainderData']['Document'] as $key3 => $value3) {
                                          foreach ($value3 as $key3 => $value3) {
                                            //print_r($value);
                                            if (is_array($value3)) {
                                              foreach ($value3 as $key3a => $value3a) {
                                                //print_r($value3a);
                                                foreach ($value3a as $key3b => $value3b) {
                                                  echo '<tr>
                                                    <td>'.$key3b.'</td>
                                                    <td>'.$value3b.'</td>
                                                  </tr>';
                                                }
                                                echo '<tr><td colspan=2 style="background-color:#cae5ff"></td></tr>';
                                              }
                                            }else{
                                              echo '<tr>
                                                    <td>'.$key3.'</td>
                                                    <td>'.$value3.'</td>
                                                  </tr>';
                                            }
                                            
                                          }
                                        } 
                                        } 

                                        ?>
                                    </table>
                                  </div>

                                  <div class="c-tabs__pane" id="nav-vital" role="tabpanel" aria-labelledby="nav-vital-tab">
                                    <h4>Vitals Information </h4>
                                    <table class="c-table">
                                      <?php  
                                      if ($dag['type']=="Full Access" || $dag['type']=="Vitals") {
                                      foreach ($value['clinicalRemainderData']['Vitals'] as $key4 => $value4) {
                                          foreach ($value4 as $key4 => $value4) {
                                            //print_r($value);
                                            if (is_array($value4)) {
                                              foreach ($value4 as $key4a => $value4a) {
                                                //print_r($value4a);
                                                foreach ($value4a as $key4b => $value4b) {
                                                  echo '<tr>
                                                    <td>'.$key4b.'</td>
                                                    <td>'.$value4b.'</td>
                                                  </tr>';
                                                }
                                                echo '<tr><td colspan=2 style="background-color:#cae5ff"></td></tr>';
                                              }
                                            }else{
                                              echo '<tr>
                                                    <td>'.$key4.'</td>
                                                    <td>'.$value4.'</td>
                                                  </tr>';
                                            }
                                            
                                          }
                                        }
                                      }

                                      $datau = strpos($dag['type'],"Document" );
                                        if (is_numeric($datau)) {
                                           foreach ($value['clinicalRemainderData']['Vitals'] as $key4 => $value4) {
                                            foreach ($value4 as $key4 => $value4) {
                                              //print_r($value);
                                              if (is_array($value4)) {
                                                foreach ($value4 as $key4a => $value4a) {
                                                  //print_r($value4a);
                                                  foreach ($value4a as $key4b => $value4b) {
                                                    echo '<tr>
                                                      <td>'.$key4b.'</td>
                                                      <td>'.$value4b.'</td>
                                                    </tr>';
                                                  }
                                                  echo '<tr><td colspan=2 style="background-color:#cae5ff"></td></tr>';
                                                }
                                              }else{
                                                echo '<tr>
                                                      <td>'.$key4.'</td>
                                                      <td>'.$value4.'</td>
                                                    </tr>';
                                              }
                                              
                                            }
                                          }
                                        } 

                                      ?>
                                    </table>
                                  </div>
                                </div>
                              </nav>

                             <?php
                            
                          // foreach ($value as $key_data => $value_data) {
                          //   if (is_array($value_data)) {
                          //       foreach ($value_data as $keyos => $valueos) {
                          //         if (is_array($valueos)) {
                          //           foreach ($valueos as $keyoo => $value00) {
                          //             if (is_array($value00)) {
                          //               continue;
                          //             }

                          //             echo '<tr>';
                          //               echo '<td>'.$keyoo.'</td>';
                          //               echo '<td>'.$value00.'</td>';
                          //             echo '</tr>';
                          //           }
                          //         }
                          //         if ($keyos=="clinicalRemainderData") {
                          //           foreach ($valueos['StepCountArr'] as $key => $value) {
                          //             echo '<tr><td colspan="2"><table class="c-table" style="text-align:left;margin:20px">';
                          //             foreach ($value as $key => $value) {
                          //               echo '<tr>
                          //                           <td style="width:350px">'.$key.'</td>
                          //                           <td>'.$value.'</td>
                          //                       </tr>';
                          //             }
                          //             echo '</table></td></tr>';
                          //           }
                          //         }
                          //          echo '<tr>';
                          //               echo '<td>'.$keyos.'</td>';
                          //               echo '<td>'.$valueos.'</td>';
                          //           echo '</tr>';
                          //       }
                          //   } 
                          //   if ($key_data=="patientData") {
                          //     echo '<tr>
                          //           <td>'.$key_data.'</td>
                          //           <td><pre>'.json_encode($value_data, JSON_PRETTY_PRINT).'</pre></td>
                          //     </tr>';
                          //   } else{
                          //     echo '<tr>';
                          //       echo '<td>'.$key_data.'</td>';
                          //       echo '<td>'.$value_data.'</td>';
                          //   echo '</tr>';
                          //   }
                            
                          // }                   
                    
                         ?>
                  
                </table>
              </div>
            </div>
          </div>
          
          <?php include 'footer.php'; ?>
        </div>
      </main>
    </div>
    <script src="js/neat.minc619.js?v=1.0"></script>
    
  </body>

</html>