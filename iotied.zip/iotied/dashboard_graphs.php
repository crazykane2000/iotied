 <div class="row">
            <div class="col-md-6">
              <div class="c-card u-ph-zero u-pb-zero">

                <div class="u-ph-medium">
                  <h4>Data Sales</h4>
                  <p>Activity from 1 Jan 2019 to 30 Dec 2019</p>

                  <span class="u-h1">$45,000</span>
                </div>

                <div class="u-p-medium">
                  <div class="c-chart">
                    <div class="sales-chart"></div>
                  </div>
                </div>
                
              </div>
            </div>

            <div class="col-md-6">
              <div class="c-card u-ph-zero u-pb-zero">

                <div class="u-ph-medium">
                  <h4>Data Growth</h4>
                  <p>Activity from 1 Jan 2018 to Till Date</p>

                  <span class="u-h1">245</span>
                </div>

                <div class="u-p-medium">
                  <div class="c-chart">
                    <div class="payouts-chart"></div>
                  </div>
                </div>
                
              </div>
            </div>
          </div>