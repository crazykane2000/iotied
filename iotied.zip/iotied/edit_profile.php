<?php session_start();
    include 'administrator/connection.php';
    include 'administrator/function.php';
    $pdo_auth = authenticate();
    $pdo = new PDO($dsn, $user, $pass, $opt);  
    error_reporting(E_ALL & ~E_NOTICE);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Dashboard  | Iotied</title>
    <meta name="description" content="Iotied">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
    <link rel="apple-touch-icon" href="apple-touch-icon.png">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="css/neat.minc619.css?v=1.0">
    <style type="text/css">
      .card-box{
        padding: 20px;
        background-color: #fff;
      }
      td
      {padding: 10px}
    </style>
  </head>
  <body>

    <div class="o-page">
      <?php include 'sidebar.php'; ?>

      <main class="o-page__content">
        <?php include 'header.php'; ?>

        <div class="container-fluid">
          <div class="row" style="min-height: 75vh">
             <!-- <div class="col-4">
              <div class="card-box items" style="height: 779px;color: #333;font-size: 14px;">
                <div style="padding: 10px;"></div>
                 <div class="century" style="font-size: 20px;color: #117ddf"> KYC Documents Rules</div>
                    <div class="century" style="font-size: 15px;color: #848d98">Know Your Customer - KYC enables Iotied to know/ understand their customers and their financial dealings, to be able to serve them better and manage its risks prudently.</div>

                    <hr style="margin:10px 0px;opacity: .4">
                    <h3 style="color: #117ddf;font-size:20px;">Purpose : </h3>
                    <ul style="color: #848d98;text-align:left;font-sixe:10px;">
                      <li>Verify the legal status of the legal person/ entity</li>
                      <li>Verify identity of the authorized signatories and</li>
                      <li>Verify identity of the Beneficial owners/ controllers of the account</li>
                    </ul>
                    <br/>
                    <h3 style="color: #117ddf;font-size:20px;">What can be used</h3>
                    <ul style="color: #333;text-align:left;">
                      <li>1. Certificate of Incorporation</li>
                      <li>2. Corporate Tax return copy cover page </li>
                      <li>3. IRS Letter sent to the Address of your Company indicating your Company EIN Number</li>

                    </ul>
                    <div style="padding:20px"></div>
              </div>
             </div> -->
            <div class="col-sm-8">
              <div class="card-box items" style="min-height: 479px;">
                <?php see_status($_REQUEST); ?>
                      <div style="padding:10px"></div>              
                        <div class="century" style="font-size: 20px;color: #333"> Upload your KYC Documents</div>
                        <div class="century" style="font-size: 13px;color: #222">You Must Upload a Government Authorised   <b style="color: red">Document</b> For Trading in Iotied </div>
                        <div style="padding:20px"></div>
                       <center>
                         <form method="POST" action="edit_profile_handle.php" enctype="multipart/form-data">
                           <div class="row">
                             <div class="col-sm-12">
                               <div class="form-group" style="text-align: left;">
                                  <label class="label" style="font-weight: bold;font-size: 13px;">Enter Company Name</label>
                                    <input type="text" class="c-input" value="<?php echo $pdo_auth['name']; ?>" name="name" placeholder="Enter Your Name">
                                    <div style="padding:10px;"></div>
                                 </div>
                             </div>

                             <div class="col-sm-12">
                               
                               <div class="form-group" style="text-align: left;">
                                <label class="label" style="font-weight: bold;font-size: 13px;">Enter Email Address</label>
                                  <input type="text" class="c-input" readonly="" name="email" value="<?php echo $pdo_auth['email']; ?>" placeholder="Enter Your Email Id">
                                  <div style="padding:10px;"></div>
                               </div>
                               

                                <div class="form-group" style="text-align: left;">
                                  <label class="label" style="font-weight: bold;font-size: 13px;">Enter Tx Address</label>
                                  <input type="text" class="c-input" name="tx_address" readonly="" value="<?php echo $pdo_auth['tx_address'];  ?>" placeholder="Enter ETH Address">
                                  <div style="padding:10px;"></div>
                               </div>

                               <div class="form-group" style="text-align: left;">
                                  <label class="label" style="font-weight: bold;font-size: 13px;">Enter Phone Number</label>
                                  <input type="text" class="c-input" name="phone"  value="<?php echo $pdo_auth['phone'];  ?>" placeholder="Enter Phone Number">
                                  <div style="padding:10px;"></div>
                               </div>

                                <div class="form-group" style="text-align: left;">
                                  <label class="label" style="font-weight: bold;font-size: 13px;">Enter Password</label>
                                  <input type="text" class="c-input" name="password"  value="<?php echo $pdo_auth['password'];  ?>" placeholder="Enter Password">
                                  <div style="padding:10px;"></div>
                               </div>

                               
                                <div class="form-group" style="text-align: left;">
                                  <label class="label" style="font-weight: bold;font-size: 13px;height: 40px;">Change Gender</label>
                                  <select class="c-input" name="gender">
                                    <option><?php echo $pdo_auth['gender']; ?></option>
                                    <option>Male</option>
                                    <option>Female</option>
                                    <option>Others </option>  
                                  </select>
                                  <div style="padding:10px;"></div>
                               </div>

                                <div class="form-group" style="text-align: left;">
                                  <label class="label" style="font-weight: bold;font-size: 13px;height: 40px;">Change Account Type</label>
                                  <select class="c-input" name="account_type">
                                    <option><?php echo $pdo_auth['type']; ?></option>
                                    <option>Laboratory</option>
                                    <option>Hospital</option>
                                    <option>Pharmacy </option>
                                    <option>Insuarance Company</option>
                                  </select>
                                  <div style="padding:10px;"></div>
                               </div>
                               

                                <!-- <div class="form-group" style="text-align: left;">
                                  <label class="label" style="font-weight: bold;font-size: 13px;">Select File</label>
                                  <input type="file" class="c-input" name="file" placeholder="Upload Your Original KYC Document">
                                  <div style="padding:10px;"></div>
                               </div> -->

                             </div>
                           </div>

                           

                           <button class="c-btn c-btn--success u-mb-xsmall" style="width: 100%" type="sumbit" name="submit">UPDATE PROFILE</button>
                         </form>
                       </center>
                       
                   </div>
            </div>

            <div class="col-4">
              <div class="card-box items" style="height: 579px;">
                <div style="padding: 10px;"></div>
                 <h3 style="color: #333;text-align:left;font-size: 20px">Change Profile Picture </h3>
                 <br/><br/>
                   
                   <?php if ($pdo_auth['file']=="default.jpg") {
                     echo '<img src="img/avatar-72.jpg" style="width: 160px">';
                   }else{
                      echo '<img src="profile/'.$pdo_auth['file'].'" style="width: 160px">';
                   }?>
                   <br/><br/>

                   <b>Name : </b> <?php echo $pdo_auth['name'];  ?><br/>
                   <b>Phone : </b> <?php echo $pdo_auth['phone'];  ?><br/>
                   <b>Email : </b> <?php echo $pdo_auth['email'];  ?><br/>
                   <b>Account Type : </b> <?php echo $pdo_auth['type'];  ?><br/>
                   <b>Tx Address : </b> <?php echo $pdo_auth['tx_address'];  ?>

                   <br/><br/>
                   <button type="button" class="c-btn c-btn--info" data-toggle="modal" data-target="#modal1">
                  Change Profile Picture
                </button>

                <div class="c-modal modal fade" id="modal1" tabindex="-1" role="dialog" aria-labelledby="modal1" aria-hidden="true" style="display: none;">
                    <div class="c-modal__dialog modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="c-card u-p-medium u-mh-auto" style="max-width:500px;">
                                <form action="change_image.php" method="POST" enctype="multipart/form-data">
                                  <h3>Select The Photo To Change</h3>
                                  
                                  <div class="form-group" style="text-align: left;">
                                  <label class="label" style="font-weight: bold;font-size: 13px;">Select File</label>
                                  <input type="file" class="c-input" name="file" placeholder="Upload Your Photo File">
                                  <div style="padding:10px;"></div>
                               </div>

                                  <button class="c-btn c-btn--info" type="submit">
                                      Change Profile Pic now
                                  </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

              </div>
            </div>

            
          </div>
         <?php include 'footer.php'; ?>
        </div>
      </main>
    </div>
    <script src="js/neat.minc619.js?v=1.0"></script>
    



  </body>

</html>