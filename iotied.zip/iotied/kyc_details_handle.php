<?php session_start();
    include 'administrator/connection.php';
    include 'administrator/function.php';
    $pdo_auth = authenticate();
    $pdo = new PDO($dsn, $user, $pass, $opt); 
    //print_r($_REQ)

    $dara = get_count_items("user_details", "user_id", $pdo_auth['id']);
    if ($dara>0) {
      $result = $pdo->exec("UPDATE `user_details` SET `street_name`='".$_REQUEST['streaat_name']."', `street_number`='".$_REQUEST['street_number']."', `po_box`='".$_REQUEST['po_box_number']."' , `city`='".$_REQUEST['city']."' , `state`='".$_REQUEST['state']."', `zip`='".$_REQUEST['zip']."' , `country`='".$_REQUEST['country']."'  WHERE `user_id`= ".$pdo_auth['id']);
    }

    $table = "user_details";
    $key_list = "`user_id`, `street_name`, `street_number`, `po_box`, `city`, `state`, `zip`, `country`, `company_identity`, `ein_number`, `primary_bank_name`, `primary_routing_no`, `primary_account_no`, `secondary_bank_name`, `secondary_routing_no`, `secondary_account_no`, `primary_first_name`, `primary_last_name`, `primary_email`, `primary_phone`, `primary_extension`, `secondary_first_name`, `secondary_last_name`, `secondary_email`, `secondary_phone`, `secondary_extension`";
    
    $value_list = "'".strip_comma($pdo_auth['id'])."',";
    $value_list .= "'".strip_comma($_REQUEST['streaat_name'])."',";
    $value_list .= "'".strip_comma($_REQUEST['street_number'])."',";
    $value_list .= "'".strip_comma($_REQUEST['po_box_number'])."',";
    $value_list .= "'".strip_comma($_REQUEST['city'])."',";
    $value_list .= "'".strip_comma($_REQUEST['state'])."',";
    $value_list .= "'".strip_comma($_REQUEST['zip'])."',";
    $value_list .= "'".strip_comma($_REQUEST['country'])."',";
    $value_list .= "'".strip_comma($_REQUEST['corporate_identity'])."',";
    $value_list .= "'".strip_comma($_REQUEST['ein_number'])."',";
    $value_list .= "'".strip_comma($_REQUEST['bank_name1'])."',";
    $value_list .= "'".strip_comma($_REQUEST['account_number1'])."',";
    $value_list .= "'".strip_comma($_REQUEST['routing_number1'])."',";
    $value_list .= "'".strip_comma($_REQUEST['bank_name2'])."',";
    $value_list .= "'".strip_comma($_REQUEST['account_number2'])."',";
    $value_list .= "'".strip_comma($_REQUEST['routing_number2'])."',";
    $value_list .= "'".strip_comma($_REQUEST['first_name1'])."',";
    $value_list .= "'".strip_comma($_REQUEST['last_name1'])."',";
    $value_list .= "'".strip_comma($_REQUEST['email1'])."',";
    $value_list .= "'".strip_comma($_REQUEST['phone1'])."',";
    $value_list .= "'".strip_comma($_REQUEST['extension_number1'])."',";
    $value_list .= "'".strip_comma($_REQUEST['first_name2'])."',";
    $value_list .= "'".strip_comma($_REQUEST['last_name2'])."',";
    $value_list .= "'".strip_comma($_REQUEST['email2'])."',";
    $value_list .= "'".strip_comma($_REQUEST['phone2'])."',";
    $value_list .= "'".strip_comma($_REQUEST['extension_number2'])."'";
    
    //echo "INSERT INTO `$table` ($key_list) VALUES ($value_list)";
    
    $result = $pdo->exec("INSERT INTO `$table` ($key_list) VALUES ($value_list)");
    //add_notification_user("A kyc Request Initiated", "user", $pdo_auth['id']);
    add_notification("A kyc is Requested from User", "admin");

     header('Location:kyc.php?choice=success&value=User Information Updated');
    
     exit();
?>
