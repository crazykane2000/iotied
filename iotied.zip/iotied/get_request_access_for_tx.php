<?php session_start();
    include 'administrator/connection.php';
    include 'administrator/function.php';
    //$pdo_auth = authenticate();
    $pdo = new PDO($dsn, $user, $pass, $opt);  
    $data = get_data_col("request_access", "patient_tx", $_REQUEST['patient_tx']);
    //print_r($data);
    $data = json_encode($data, JSON_PRETTY_PRINT);
    print_r($data);
?>