<?php session_start();
    include 'administrator/connection.php';
    include 'administrator/function.php';
    $pdo_auth = authenticate();
    $pdo = new PDO($dsn, $user, $pass, $opt); 
    //print_r($_REQUEST);

    $device_token = get_device_id_from_tx($_REQUEST['patient_tx']);
    $device_token = json_decode($device_token,true);
    //print_r( $device_token);
    $device_token =  $device_token[0]['deviceToken'];
   
   	$darat = explode(" -- ", $_REQUEST['plan']);

    // Provide the Host Information.
    $tHost = "gateway.sandbox.push.apple.com";
    //$tHost = "gateway.push.apple.com";
    $tPort = 2195;
    // Provide the Certificate and Key Data.
    $tCert = "CertificatesBCAPNS.pem";
    $tPassphrase = "123456";
    $tToken = $device_token;
    // Audible Notification Option.
    $tSound = "default";
    // The content that is returned by the LiveCode “pushNotificationReceived” message.
    $tPayload = "APNS payload";
    // Create the message content that is to be sent to the device.
    // Create the payload body
    //Below code for non silent notification
    $tBody["aps"] = array(
    "badge" => +1,
    "alert" => "A Vendor (".$pdo_auth['name'].") Wants to Access Your Data,  Tx address of Vendor is : ".$pdo_auth['tx_address'],
    "sound" => "default"
    );
    $tBody ["payload"] = $tPayload;
    // Encode the body to JSON.
    $tBody = json_encode ($tBody);
    // Create the Socket Stream.
    $tContext = stream_context_create ();
    stream_context_set_option ($tContext, "ssl", "local_cert", $tCert);
    // Remove this line if you would like to enter the Private Key Passphrase manually.
    stream_context_set_option ($tContext, "ssl", "passphrase", $tPassphrase);
    // Open the Connection to the APNS Server.
    $tSocket = stream_socket_client ("ssl://".$tHost.":".$tPort, $error, $errstr, 30, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $tContext);
    // Check if we were able to open a socket.
    if (!$tSocket)
    exit ("APNS Connection Failed: $error $errstr" . PHP_EOL);
    // Build the Binary Notification.
    $tMsg = chr (0) . chr (0) . chr (32) . pack ("H*", $tToken) . pack ("n", strlen ($tBody)) . $tBody;
    // Send the Notification to the Server.
    $tResult = fwrite ($tSocket, $tMsg, strlen ($tMsg));
    if ($tResult){
        $table = "request_access";
        $key_list = "`vendor_tx`, `patient_tx`, `tx`,`status`,`plan`, `days`, `reward_point`, `currency`, `type`, `vendor_name`";        
        $value_list  = "'".$pdo_auth['tx_address']."',";
        $value_list  .= "'".$_REQUEST['patient_tx']."',";
        $value_list  .= "'request_to_access',";
        $value_list  .= "'Pending',";
        $value_list  .= "'".$darat[0]."',";
        $value_list  .= "'".$_REQUEST['duration']."',";
        $value_list  .= "'".$darat[1]."',";
        $value_list  .= "'".$_REQUEST['currency']."',";
        $value_list  .= "'".$_REQUEST['type']."',";
        $value_list  .= "'".$pdo_auth['name']."'";

        //echo "INSERT INTO `$table` ($key_list) VALUES ($value_list)";
        
        $result = $pdo->exec("INSERT INTO `$table` ($key_list) VALUES ($value_list)");
        header('Location:view_request_to_access.php?choice=success&value=Support Request Added Successfully');              
        exit();
    }else{
        header('Location:dashboard.php?choice=error&value='."Could not Deliver Message to APNS" . PHP_EOL);              
        exit();
    }
?>
