<?php session_start();
    include 'administrator/connection.php';
    include 'administrator/function.php';
    $pdo_auth = authenticate();
    $pdo = new PDO($dsn, $user, $pass, $opt);  
    error_reporting( E_WARNING | E_PARSE);
?>
<?php $dag =  get_data_items_andd("request_access", "vendor_tx", $pdo_auth['tx_address'], "patient_tx", $_REQUEST['address']); 
   //print_r($dag);
  // echo $dag['type'];

  if ($dag['type']=="None"  || $dag['type']=="No Access" ) {
    header('Location:dashboard.php?choice=error&value=Access Is Not Given, No Access Rights are Given');
    exit();
  }
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Dashboard  | Iotied</title>
    <meta name="description" content="Iotied">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
    <link rel="apple-touch-icon" href="apple-touch-icon.png">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="css/neat.minc619.css?v=1.0">
    <style type="text/css">
      td{
        padding: 6px;
        padding-left: 20px;
        border-bottom: solid 1px #eee;
        text-transform: capitalize;
        font-size: 13px;
      }
    </style>
  </head>
  <body>

    <div class="o-page">
      <?php include 'sidebar.php'; ?>

      <main class="o-page__content">
        <?php include 'header.php'; ?>

        <div class="container-fluid">
          <?php include 'dashboard_stats.php'; ?>



          <?php $curl = curl_init();

              curl_setopt_array($curl, array(
              CURLOPT_URL => "http://13.233.7.230:3005/api/dataManager/get/patients",
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => "",
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 0,
              CURLOPT_FOLLOWLOCATION => true,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => "GET",
              CURLOPT_HTTPHEADER => array(
                "Content-Type: application/json"
              ),
            ));

            $response = curl_exec($curl);

              curl_close($curl);

              if ($err) {
                echo "cURL Error #:" . $err;
              } else {
                $response = json_decode($response,true);
              } 
              //print_r($response);
              ?>
          <div class="row">
            <div class="col-12">
              <div class="c-table-responsive@wide" style="background-color: #fff;padding: 30px;border-radius: 4px;">
                <table class="c-table">
                  <?php
                  $i=0;
                    foreach ($response as $key => $value) {
                      if ($value['patientAddress']!=$dag['patient_tx']) {
                        continue;
                      }

                      echo '<tr>
                                <td>'.$value['patientAddress'].'</td>
                                <td>'.$value['actionPerformed'].'</td>
                                <td>'.date('d/m/Y H:i:s', ($value['timestamp']/1000000000)).'</td>
                                <td><a target="_blank" href="view_data_arch.php?i='.$i.'&address='.$value['patientAddress'].'" class="c-btn c-btn--success c-btn--small">View Data</a></td>
                              </tr>';
                              $i++;
                    }

                  ?>
                </table>
                <div style="padding: 20px"></div>
              </div>
            </div>
          </div>
          
          <?php include 'footer.php'; ?>
        </div>
      </main>
    </div>
    <script src="js/neat.minc619.js?v=1.0"></script>
    
  </body>

</html>