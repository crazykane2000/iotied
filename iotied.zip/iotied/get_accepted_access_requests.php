<?php session_start();
    include 'administrator/connection.php';
    include 'administrator/function.php';
    //$pdo_auth = authenticate();
    $pdo = new PDO($dsn, $user, $pass, $opt);  

    try {
          $stmt = $pdo->prepare('SELECT * FROM `request_access` WHERE `vendor_tx`="'.$_REQUEST['vendor_tx'].'"  ORDER BY date DESC');
          //echo 'SELECT * FROM `request_access` WHERE `vendor_tx`="'.$_REQUEST['vendor_tx'].'"  ORDER BY date DESC';
      } catch(PDOException $ex) {
          echo "An Error occured!"; 
          print_r($ex->getMessage());
      }
      $stmt->execute();
      $data = $stmt->fetchAll();
    //print_r($data);

    $data = json_encode($data, JSON_PRETTY_PRINT);
    print_r($data);
?>