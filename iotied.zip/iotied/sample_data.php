<?php session_start();
    include 'administrator/connection.php';
    include 'administrator/function.php';
    $pdo_auth = authenticate();
    $pdo = new PDO($dsn, $user, $pass, $opt);  
    error_reporting( E_WARNING | E_PARSE);
?>
<?php $dag =  get_data_items_andd("request_access", "vendor_tx", $pdo_auth['tx_address'], "patient_tx", $_REQUEST['address']); 
   //print_r($dag);
  // echo $dag['type'];

  if ($dag['type']=="None"  || $dag['type']=="No Access" ) {
    header('Location:dashboard.php?choice=error&value=Access Is Not Given, No Access Rights are Given');
    exit();
  }
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Dashboard  | Iotied</title>
    <meta name="description" content="Iotied">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
    <link rel="apple-touch-icon" href="apple-touch-icon.png">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="css/neat.minc619.css?v=1.0">
    <style type="text/css">
      td{
        padding: 6px;
        padding-left: 20px;
        border-bottom: solid 1px #eee;
        text-transform: capitalize;
      }
    </style>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.6.1/css/buttons.dataTables.min.css">
  </head>
  <body>

    <div class="o-page">
      <?php include 'sidebar.php'; ?>

      <main class="o-page__content">
        <?php include 'header.php'; ?>

        <div class="container-fluid">
          <?php include 'dashboard_stats.php'; ?>



          <?php $curl = curl_init();

              $patient = $_REQUEST['address'];
              $vendor = $pdo_auth['tx_address'];

              //echo $patient." / ".$vendor;

              
              curl_setopt_array($curl, array(
                CURLOPT_URL => "http://13.233.7.230:3005/api/dataManager/getDetails/patient",
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_POSTFIELDS =>"{\n  \"_vendorAddress\": \"$vendor\",\n  \"_patientAddress\": \"$patient\"\n}",
                  CURLOPT_HTTPHEADER => array(
                    "Content-Type: application/json"
                  ),
                ));

              $response = curl_exec($curl);

              curl_close($curl);

              if ($err) {
                echo "cURL Error #:" . $err;
              } else {
                $response = json_decode($response,true);
              } 
              //print_r($response);
              ?>
          <div class="row">
            <div class="col-12">
              <div class="c-table-responsive@wide" style="background-color: #fff;padding: 30px;border-radius: 4px;">
                <table class="c-table" id="example">
                  <thead>
                    <tr>
                      <th style="text-align: left;padding: 10px">Key</th>
                      <th style="text-align: left;padding: 10px">Value</th>
                    </tr>
                  </thead>
                  <tbody>
                  
                  <?php $value = $response;
                            
                            echo '<tr>
                                <td>Tx Address</td>
                                <td>'.$pdo_auth['tx_address'].'</td>
                              </tr>';

                              echo '<tr>
                                <td>patientAddress</td>
                                <td>'.$_REQUEST['address'].'</td>
                              </tr>';

                              

                              echo '<tr>
                                <td>First Name</td>
                                <td style="color:green;font-weight:bold">'.$value['First Name'].'</td>
                              </tr>';

                              echo '<tr>
                                <td>City</td>
                                <td>'.$value['City'].'</td>
                              </tr>';

                              echo '<tr>
                                <td>Home Phone</td>
                                <td>'.$value['Home Phone'].'</td>
                              </tr>';

                              echo '<tr>
                                <td>Emergency Contact</td>
                                <td>'.$value['Emergency Contact'].'</td>
                              </tr>';

                               echo '<tr>
                                <td>Diseases</td>
                                <td>'.$value['diseases'].'</td>
                              </tr>';

                              echo '<tr>
                                <td>ICD Codes</td>
                                <td>'.$value['icd_code'].'</td>
                              </tr>';

                              $vital_arr = $value['clinicalRemainderData']['VitalArr'];

                              ?>
                              <tr>
                                <td >
                                  <h3>Personal Information</h3>
                                </td>
                                <td>7</td>
                              </tr>

                              <?php 
                                        if ($dag['type']=="Full Access" || $dag['type']=="PersonalInformation") {
                                          //print_r($value['clinicalRemainderData']['PersonalInformation']);
                                            foreach ($value['clinicalRemainderData']['PersonalInformation'] as $key1 => $value1) {
                                              foreach ($value1 as $key1 => $value1) {
                                                //print_r($value);
                                                echo '<tr>
                                                        <td>'.$key1.'</td>
                                                        <td>'.$value1.'</td>
                                                      </tr>';
                                              }
                                            }
                                        }


                                        $datau = strpos($dag['type'],"PersonalInformation" );
                                        if (is_numeric($datau)) {
                                          foreach ($value['clinicalRemainderData']['PersonalInformation'] as $key1 => $value1) {
                                              foreach ($value1 as $key1 => $value1) {
                                                //print_r($value);
                                                echo '<tr>
                                                        <td>'.$key1.'</td>
                                                        <td>'.$value1.'</td>
                                                      </tr>';
                                              }
                                            }
                                        } 
                                        
                                          
                                       ?>
                                       <tr>
                                <td >
                                  <h3>Wearable Information</h3>
                                </td>
                                <td>.</td>
                              </tr>

                                       <?php 
                                        if ($dag['type']=="Full Access" || $dag['type']=="Wearable") {
                                          foreach ($value['clinicalRemainderData']['Wearable'] as $key2 => $value2) {
                                            foreach ($value2 as $key2 => $value2) {
                                              //print_r($value);
                                              if (is_array($value2)) {
                                                foreach ($value2 as $key2a => $value2a) {
                                                  //print_r($value2a);
                                                  foreach ($value2a as $key2b => $value2b) {
                                                    echo '<tr>
                                                      <td>'.$key2b.'</td>
                                                      <td>'.$value2b.'</td>
                                                    </tr>';
                                                  }
                                                  echo '<tr><td  style="background-color:#cae5ff">......</td><td  style="background-color:#cae5ff">......</td></tr>';
                                                }
                                              }else{
                                                echo '<tr>
                                                      <td>'.$key2.'</td>
                                                      <td>'.$value2.'</td>
                                                    </tr>';
                                              }
                                              
                                            }
                                          }
                                        }

                                        $datau = strpos($dag['type'],"Wearable" );
                                        if (is_numeric($datau)) {
                                         foreach ($value['clinicalRemainderData']['Wearable'] as $key2 => $value2) {
                                            foreach ($value2 as $key2 => $value2) {
                                              //print_r($value);
                                              if (is_array($value2)) {
                                                foreach ($value2 as $key2a => $value2a) {
                                                  //print_r($value2a);
                                                  foreach ($value2a as $key2b => $value2b) {
                                                    echo '<tr>
                                                      <td>'.$key2b.'</td>
                                                      <td>'.$value2b.'</td>
                                                    </tr>';
                                                  }
                                                  echo '<tr><td  style="background-color:#cae5ff">......</td><td  style="background-color:#cae5ff">......</td></tr>';
                                                }
                                              }else{
                                                echo '<tr>
                                                      <td>'.$key2.'</td>
                                                      <td>'.$value2.'</td>
                                                    </tr>';
                                              }
                                              
                                            }
                                          }
                                        } 

                                       ?>

                                       <tr>
                                <td >
                                  <h3>Document Information</h3>
                                </td>
                                <td>.</td>
                              </tr>

                                       <?php 
                                      if ($dag['type']=="Full Access" || $dag['type']=="Document") {
                                      foreach ($value['clinicalRemainderData']['Document'] as $key3 => $value3) {
                                        foreach ($value3 as $key3 => $value3) {
                                          //print_r($value);
                                          if (is_array($value3)) {
                                            foreach ($value3 as $key3a => $value3a) {
                                              //print_r($value3a);
                                              foreach ($value3a as $key3b => $value3b) {
                                                echo '<tr>
                                                  <td>'.$key3b.'</td>
                                                  <td>'.$value3b.'</td>
                                                </tr>';
                                              }
                                              echo '<tr><td  style="background-color:#cae5ff">......</td><td  style="background-color:#cae5ff">......</td></tr>';
                                            }
                                          }else{
                                            echo '<tr>
                                                  <td>'.$key3.'</td>
                                                  <td>'.$value3.'</td>
                                                </tr>';
                                          }
                                          
                                        }
                                      } 

                                    }

                                    $datau = strpos($dag['type'],"Document" );
                                        if (is_numeric($datau)) {
                                         foreach ($value['clinicalRemainderData']['Document'] as $key3 => $value3) {
                                          foreach ($value3 as $key3 => $value3) {
                                            //print_r($value);
                                            if (is_array($value3)) {
                                              foreach ($value3 as $key3a => $value3a) {
                                                //print_r($value3a);
                                                foreach ($value3a as $key3b => $value3b) {
                                                  echo '<tr>
                                                    <td>'.$key3b.'</td>
                                                    <td>'.$value3b.'</td>
                                                  </tr>';
                                                }
                                                echo '<tr><td  style="background-color:#cae5ff">......</td><td  style="background-color:#cae5ff">......</td></tr>';
                                              }
                                            }else{
                                              echo '<tr>
                                                    <td>'.$key3.'</td>
                                                    <td>'.$value3.'</td>
                                                  </tr>';
                                            }
                                            
                                          }
                                        } 
                                        } 

                                        ?>
                                        <tr>
                                <td >
                                  <h3>Vital Information</h3>
                                </td>
                                <td>.</td>
                              </tr>

                                         <?php  
                                      if ($dag['type']=="Full Access" || $dag['type']=="Vitals") {
                                      foreach ($value['clinicalRemainderData']['Vitals'] as $key4 => $value4) {
                                          foreach ($value4 as $key4 => $value4) {
                                            //print_r($value);
                                            if (is_array($value4)) {
                                              foreach ($value4 as $key4a => $value4a) {
                                                //print_r($value4a);
                                                foreach ($value4a as $key4b => $value4b) {
                                                  echo '<tr>
                                                    <td>'.$key4b.'</td>
                                                    <td>'.$value4b.'</td>
                                                  </tr>';
                                                }
                                                echo '<tr><td  style="background-color:#cae5ff">......</td><td  style="background-color:#cae5ff">......</td></tr>';
                                              }
                                            }else{
                                              echo '<tr>
                                                    <td>'.$key4.'</td>
                                                    <td>'.$value4.'</td>
                                                  </tr>';
                                            }
                                            
                                          }
                                        }
                                      }

                                      $datau = strpos($dag['type'],"Document" );
                                        if (is_numeric($datau)) {
                                           foreach ($value['clinicalRemainderData']['Vitals'] as $key4 => $value4) {
                                            foreach ($value4 as $key4 => $value4) {
                                              //print_r($value);
                                              if (is_array($value4)) {
                                                foreach ($value4 as $key4a => $value4a) {
                                                  //print_r($value4a);
                                                  foreach ($value4a as $key4b => $value4b) {
                                                    echo '<tr>
                                                      <td>'.$key4b.'</td>
                                                      <td>'.$value4b.'</td>
                                                    </tr>';
                                                  }
                                                  echo '<tr><td  style="background-color:#cae5ff">......</td><td  style="background-color:#cae5ff">......</td></tr>';
                                                }
                                              }else{
                                                echo '<tr>
                                                      <td>'.$key4.'</td>
                                                      <td>'.$value4.'</td>
                                                    </tr>';
                                              }
                                              
                                            }
                                          }
                                        } 

                                      ?>
                                    </tbody>
                            </table>
                            <div style="padding: 20px"></div>
  
                  
                
              </div>
            </div>
          </div>
          
          <?php include 'footer.php'; ?>
        </div>
      </main>
    </div>
    <script src="js/neat.minc619.js?v=1.0"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.1/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.flash.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.print.min.js"></script>
    <script type="text/javascript">
      $(document).ready(function() {
          $('#example').DataTable({ "paging": false, "ordering": false, dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]});
      } );
    </script>
  </body>

</html>