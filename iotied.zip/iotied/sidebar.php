<div class="o-page__sidebar js-page-sidebar">
        <aside class="c-sidebar">
          <div class="c-sidebar__brand">
            <a href="dashboard.php"><img src="img/logog.png" style="width: 100px;" alt="Iotied"></a>
          </div>

          <!-- Scrollable -->
          <div class="c-sidebar__body">
            <ul class="c-sidebar__list">
              <li>
                <a class="c-sidebar__link" href="dashboard.php">
                  <i class="c-sidebar__icon feather icon-home"></i>Dashboard 
                </a>
              </li>    

              <li>
                <a class="c-sidebar__link" href="plans.php">
                  <i class="c-sidebar__icon feather icon-home"></i>Plans 
                </a>
              </li> 

               <li>
                <a class="c-sidebar__link" href="kyc.php">
                  <i class="c-sidebar__icon feather icon-home"></i>KYC
                </a>
              </li> 

              <li>
                <a class="c-sidebar__link" href="buy_request.php">
                  <i class="c-sidebar__icon feather icon-home"></i>Buy Request
                </a>
              </li>    
  

               <li>
                <a class="c-sidebar__link" href="wallet.php">
                  <i class="c-sidebar__icon feather icon-home"></i>My Wallet 
                </a>
              </li>    

              <li>
                <a class="c-sidebar__link" href="support.php">
                  <i class="c-sidebar__icon feather icon-home"></i>Support
                </a>
              </li>  
<!-- 
               <li>
                <a class="c-sidebar__link" href="dashboard.php">
                  <i class="c-sidebar__icon feather icon-home"></i>Smart Contracts
                </a>
              </li>    --> 

            </ul>

            <span class="c-sidebar__title">Transactions</span>
            <ul class="c-sidebar__list">
              <!-- <li>
                <a class="c-sidebar__link" href="pipeline.html">
                  <i class="c-sidebar__icon feather icon-user"></i>Credit to Bank
                </a>
              </li>
              <li>
                <a class="c-sidebar__link" href="calendar.html">
                  <i class="c-sidebar__icon feather icon-user"></i>Requests
                </a>
              </li> -->
              <li>
                <a class="c-sidebar__link" href="transactions.php">
                  <i class="c-sidebar__icon feather icon-users"></i>Transactions
                </a>
              </li>
               
               <li>
                <a class="c-sidebar__link" href="view_producers.php">
                  <i class="c-sidebar__icon feather icon-users"></i>Total Producers
                </a>
              </li><li>
                <a class="c-sidebar__link" href="view_request_to_access.php">
                  <i class="c-sidebar__icon feather icon-users"></i>View Access requests
                </a>
              </li>
              <li>
                <a class="c-sidebar__link" href="white_listed_producers.php">
                  <i class="c-sidebar__icon feather icon-users"></i>Whitelisted Producers
                </a>
              </li>
             
              
            </ul>


          </div>
          

          <a class="c-sidebar__footer" href="logout.php">
            Logout <i class="c-sidebar__footer-icon feather icon-power"></i>
          </a>
        </aside>
      </div>