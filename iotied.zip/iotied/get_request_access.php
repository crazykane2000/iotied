<pre><?php session_start();
    include 'administrator/connection.php';
    include 'administrator/function.php';
    //$pdo_auth = authenticate();
    $pdo = new PDO($dsn, $user, $pass, $opt);  
    $data = fetch_all_popo("request_access");
    //print_r($data);

    $data = json_encode($data, JSON_PRETTY_PRINT);
    print_r($data);
?></pre>