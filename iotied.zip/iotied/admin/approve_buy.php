<?php //session_start();
    include '../administrator/connection.php';
    include '../administrator/function.php';
    //$pdo_auth = authenticate_admin();
    $pdo = new PDO($dsn, $user, $pass, $opt);  
   
    $table = "buy_token";

    $data = get_data_id_data("buy_token", "id", $_REQUEST['id']);


    add_wallet_balance($_REQUEST['tx_address'],$data['no_of_tokens']);
    $result = $pdo->exec("UPDATE `$table` SET `status`='Approved' WHERE `id`=".$_REQUEST['id']);
    //echo $data;
    header('Location:buy_requests.php?choice=success&value=Buy Request Approved Successfully');              
    exit();