<?php $curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "http://13.233.7.230:3005/api/dataManager/whitelist/address",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS =>"{\n  \"_patientAddress\": \"0x8db058e36f1672a4cf965be8f349a032c5868666\", \n  \"_addressToWhitelist\": \"0x20c5672358a46463edaf53d705049e3fbc326efc\",\n  \"_currency\" : \"IOTied\",\n  \"_rewardAmount\" : \"10\",\n  \"_type\" : \"Vitals\"\n}",
  CURLOPT_HTTPHEADER => array(
    "Content-Type: application/json"
  ),
));

$response = curl_exec($curl);

curl_close($curl);
echo $response;
