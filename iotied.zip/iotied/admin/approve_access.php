<?php //session_start();
    include '../administrator/connection.php';
    include '../administrator/function.php';
    //$pdo_auth = authenticate_admin();
    $pdo = new PDO($dsn, $user, $pass, $opt);  
   
    $table = "request_access";

    $data = get_data_id_data("request_access", "id", $_REQUEST['id']);
    //print_r($data);
    $patient_address = $data['patient_tx'];
    $vendor_address = $data['vendor_tx'];
    $reward_point = $data['reward_point'];
    $currency = "USD";
    if ($data['currency']=="Dollar") {
        $currency = "USD";
    }else{
        $currency = "IOTied";
    }
    //$currency = $data['currency'];
    $type = $data['type'];
    $data = "{\n  \"_patientAddress\": \"$patient_address\", \n  \"_addressToWhitelist\": \"$vendor_address\",\n  \"_currency\" : \"$currency\",\n  \"_rewardAmount\" : \"$reward_point\",\n  \"_type\" : \"$type\"\n}";
    
    $length = strlen($data);
    $curl = curl_init();
    curl_setopt_array($curl, array(
      CURLOPT_URL => "http://13.233.7.230:3005/api/dataManager/whitelist/address",
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => "",
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => "POST",
      CURLOPT_POSTFIELDS =>$data,
      CURLOPT_HTTPHEADER => array(
        "Content-Type: application/json",
      ),
    ));

    $response = curl_exec($curl);

    curl_close($curl);
    $data = json_decode($response,true);
   
    $result = $pdo->exec("UPDATE `$table` SET `status`='Approved', `approve_date`='".date("Y-m-d H:i:s")."', `tx`='".$data['txHash']."' WHERE `id`=".$_REQUEST['id']);
    //echo $data;
    header('Location:patient_data_access.php?choice=success&value=Access Approved Successfully');              
    exit();
?>
