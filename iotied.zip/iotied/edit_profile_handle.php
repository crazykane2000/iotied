<?php session_start();
    include 'administrator/connection.php';
    include 'administrator/function.php';
    $pdo_auth = authenticate();
    $pdo = new PDO($dsn, $user, $pass, $opt); 

    $table = "users";
    //$key_list = "`name`,`phone`, `password`, `gender`, `type`, `email`";
    
    // $value_list = "'".$_REQUEST['name']."',";
    // $value_list .= "'".$_REQUEST['phone']."',";
    // $value_list .= "'".$_REQUEST['password']."',";
    // $value_list.="'".$_REQUEST['gender']."',";
    // $value_list.="'".$_REQUEST['account_type']."',";
    // $value_list.="'".$_REQUEST['email']."'";
    
    //echo "INSERT INTO `$table` ($key_list) VALUES ($value_list)";
    
    $result = $pdo->exec("UPDATE `users` SET `name`='".$_REQUEST['name']."', `phone`='".$_REQUEST['phone']."', `password`='".$_REQUEST['password']."' , `gender`='".$_REQUEST['gender']."' , `type`='".$_REQUEST['account_type']."', `email`='".$_REQUEST['email']."' WHERE id= ".$pdo_auth['id']);
    //add_notification_user("A kyc Request Initiated", "user", $pdo_auth['id']);
    //add_notification("A kyc is Requested from User", "admin");

     header('Location:edit_profile.php?choice=success&value=Profile Updated successFully');
     exit();
?>
